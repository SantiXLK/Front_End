const url = 'http://localhost:5000/canciones';

fetch(url)
.then(response => response.json()) 
.then(data => {
    
    let canciones = data;

    let tabla = document.createElement('table');
    tabla.border = '1';

    let fila = document.createElement('tr');
    let columnas = ['ID', 'Título', 'Minutos', 'Segundos', 'Intérprete'];
    for (let columna of columnas) {
        let celda = document.createElement('th');
        celda.textContent = columna;
        fila.appendChild(celda);
    }
    tabla.appendChild(fila);

    for (let cancion of canciones) {
        let fila = document.createElement('tr');
        for (let dato in cancion) {
            let celda = document.createElement('td');
            celda.textContent = cancion[dato];
            fila.appendChild(celda);
        }
        tabla.appendChild(fila);
    }

    let divTabla = document.getElementById('tabla');
    divTabla.appendChild(tabla);
})
.catch(error => {
    console.error(error);
});
